package com.example.w4a_todoprovider;

import android.content.ContentProvider;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;

import java.util.Arrays;
import java.util.HashSet;

//This is a very imp class as this is where we do query

public class MyToDoContentProvider extends ContentProvider {

    private DatabaseHandler database;

    private static final int TODOS = 10;
    private static final int TODO_ID = 20;
    private static final String AUTHORITY = "com.example.todo.todos.contentprovider";
    private static final String BASE_PATH = "todos";
    private static final Uri CONTENT_URI = Uri.parse("content://"+AUTHORITY+"/"+BASE_PATH);

    public static final String CONTENT_TYPE = ContentResolver.CURSOR_DIR_BASE_TYPE+"/todos";
    public static final String CONTENT_ITEM_TYPE = ContentResolver.CURSOR_ITEM_BASE_TYPE+"/todo";
    public static final UriMatcher sURIMatcher = new UriMatcher(UriMatcher.NO_MATCH);

    static{

        sURIMatcher.addURI(AUTHORITY,BASE_PATH,TODOS);  //All rows or records
        sURIMatcher.addURI(AUTHORITY,BASE_PATH +"/#",TODO_ID); //particular row or record
    }

    @Override
    public boolean onCreate() {
        database = new DatabaseHandler(getContext())
        return false;
    }

    @androidx.annotation.Nullable
    @Override
    public Cursor query(@androidx.annotation.NonNull Uri uri,
                        @androidx.annotation.Nullable String[] projection,
                        @androidx.annotation.Nullable String selection,
                        @androidx.annotation.Nullable String[] selectionArgs,
                        @androidx.annotation.Nullable String sortOrder) {
        //URI - universal resource ID to identify the record
        //Cursor  - Temp Table that holds subset of the Data for Query
        //Projection means the actual Data Table Structure e.g DataTable - Id, Name, Age, Address, Phone
        //Selection means the Selection Arguments i.e Table col. to display - Select Name,Phone
        //                                                         Table Name FROM Contacts
        //                                                          Criteria  Where Id = "1"
        //                                                         SortOrder  Order By Id ASC
        //                                                                    Having


        //Using SQLite instead of query() method
        SQLiteQueryBuilder querybuilder = new SQLiteQueryBuilder();

        //Check if the caller has requested a column which does not exist
        checkColumns(projection);

        //Set the table
        querybuilder.setTables(ToDoTableHandler.TABLE_TODO);
        int uriType = sURIMatcher.match(uri);
        switch (uriType){
            case TODOS:
                break;
            case TODO_ID:
                querybuilder.appendWhere(ToDoTableHandler.COLUMN_ID+"="+uri.getLastPathSegment());
                //getLastPathSegment is the last part i.e Id (content//Authority/ToDo/3)
                break;
            default:
                throw new IllegalArgumentException("Unknown URI: "+ uri);
        }

        // THE ACTUAL PART TO CREATING A QUERY
        SQLiteDatabase db = database.getWritableDatabase();
        Cursor cursor = querybuilder.query(db,projection,selection,selectionArgs,null,null,sortOrder);

        //Make sure that potential listners are getting notified
        cursor.setNotificationUri(getContext().getContentResolver(),uri);

        return cursor;
    }

    @androidx.annotation.Nullable
    @Override
    public Uri insert(@androidx.annotation.NonNull Uri uri, @androidx.annotation.Nullable ContentValues values) {
        return null;
    }

    @androidx.annotation.Nullable
    @Override
    public String getType(@androidx.annotation.NonNull Uri uri) {
        return null;
    }

    @Override
    public int delete(@androidx.annotation.NonNull Uri uri, @androidx.annotation.Nullable String selection, @androidx.annotation.Nullable String[] selectionArgs) {
        return 0;
    }

    @Override
    public int update(@androidx.annotation.NonNull Uri uri, @androidx.annotation.Nullable ContentValues values, @androidx.annotation.Nullable String selection, @androidx.annotation.Nullable String[] selectionArgs) {
        return 0;
    }

    private void checkColumns(String[] projection){
        String[] available = {ToDoTableHandler.COLUMN_CATEGORY,
                              ToDoTableHandler.COLUMN_SUMMARY,
                ToDoTableHandler.COLUMN_DESCRIPTION,
                ToDoTableHandler.COLUMN_ID};

        //HashSet store elements using hashing
        //allows null values,Unique elements No Duplicates
        //doesn't maintain search order
        //Here HashSet is used to check if the requested Columns in SELECT query are available or not from the
        //projection (Table structure (design))
        if(projection != null){
            //Arrays.asList is used to return fixed size list with no duplicates
            HashSet<String> requestColumns = new HashSet<String>(Arrays.asList(projection));
            HashSet<String> availableColumns = new HashSet<String>(Arrays.asList(available));

            if(!availableColumns.containsAll((requestColumns))){
                throw new IllegalArgumentException("Unknown columns in projection");
            }
        }
    }
}
